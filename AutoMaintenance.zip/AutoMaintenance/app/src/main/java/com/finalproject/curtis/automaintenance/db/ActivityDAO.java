package com.finalproject.curtis.automaintenance.db;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;

import java.util.List;

@Dao
public interface ActivityDAO {

    @Query("select * from activity WHERE userID = :userid")
    LiveData<List<Activity>> getAll(int userid);

    @Query("select * from activity WHERE aid = :id")
    List<Activity> loadByID(int id);

    @Query("select * from activity where vehicle_nickname = :nickname")
    Activity loadByNickName(String nickname);

    @Update
    void update(Activity activity);

    @Delete
    void delete(Activity activity);

    @Insert
    void insert(Activity... activities);

}
