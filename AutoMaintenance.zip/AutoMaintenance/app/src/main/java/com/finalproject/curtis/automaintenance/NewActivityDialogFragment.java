package com.finalproject.curtis.automaintenance;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputEditText;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.Spinner;
import android.widget.TextView;
import com.finalproject.curtis.automaintenance.db.Activity;
import com.finalproject.curtis.automaintenance.db.AppDatabase;
import com.finalproject.curtis.automaintenance.db.User;
import com.finalproject.curtis.automaintenance.db.Vehicle;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class NewActivityDialogFragment extends DialogFragment {

    private View root;
    private Spinner edtNickname;
    private Spinner edtActivityType;
    private TextInputEditText edtLocation;
    private TextInputEditText edtMiles;
    private TextInputEditText edtCost;
    private TextView edtDate;
    private Button btnDate;
    private Calendar calendar;
    private DatePickerDialog datePickerDialog;
    private String username = "";
    int userID = 0;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        root = inflater.inflate(R.layout.dialog_new_activity, container, false);
        setCancelable(false);

        Toolbar toolbar = (Toolbar) root.findViewById(R.id.toolbar1);
        toolbar.setTitle("New Activity");

        ((AppCompatActivity)getActivity()).setSupportActionBar(toolbar);

        ActionBar actionBar = ((AppCompatActivity)getActivity()).getSupportActionBar();

        if(actionBar != null)
        {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeButtonEnabled(true);
            actionBar.setHomeAsUpIndicator(android.R.drawable.ic_menu_close_clear_cancel);
        }

        setHasOptionsMenu(true);

        // Getting UserID so I can pull vehicleNicknames based on that UserID
        Bundle bundle = this.getArguments();
        if (bundle != null) {
            username = bundle.getString("username", "none");
        }

        List<User> users1 = AppDatabase.getInstance(getContext()).userDAO().getAllByUsername(username);

        for(User usr : users1) {
            userID = usr.getUserID();
        }

        // Set up String ArrayList for all vehicleNicknames
        ArrayList<String> nickNames = new ArrayList<String>();

        List<Vehicle> vehicles = AppDatabase.getInstance(getContext()).vehicleDAO().loadByUserID(userID);
        String vehicleName = "";

        for(Vehicle vehc : vehicles) {
            vehicleName = vehc.getVehiclenickname();

            nickNames.add(vehicleName);
        }


        edtNickname = (Spinner) root.findViewById(R.id.edtNicknameSpinner);
        edtActivityType = (Spinner) root.findViewById(R.id.edtActivityTypeSpinner);
        edtDate = (TextView) root.findViewById(R.id.edtDateValue);
        edtLocation = (TextInputEditText) root.findViewById(R.id.edtLocationValue);
        edtMiles = (TextInputEditText) root.findViewById(R.id.edtMilesValue);
        edtCost = (TextInputEditText) root.findViewById(R.id.edtCostValue);

        btnDate = (Button) root.findViewById(R.id.btnselectDate);

        btnDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                calendar = Calendar.getInstance();
                int day = calendar.get(Calendar.DAY_OF_MONTH);
                int month = calendar.get(Calendar.MONTH);
                int year = calendar.get(Calendar.YEAR);

                datePickerDialog = new DatePickerDialog(getContext(), R.style.DialogTheme, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int mYear, int mMonth, int mDay) {
                        edtDate.setText(mMonth + "/" + mDay + "/" + mYear);
                    }
                }, year, month, day);
                datePickerDialog.show();
            }
        });


        Spinner activitySpinner = (Spinner) root.findViewById(R.id.edtActivityTypeSpinner);

        ArrayAdapter<String> activityAdapter = new ArrayAdapter<String>(getContext(),
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.activityNames));
        activityAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        activitySpinner.setAdapter(activityAdapter);

        Spinner nicknameSpinner = (Spinner) root.findViewById(R.id.edtNicknameSpinner);

        ArrayAdapter<String> vehicleNicknameAdapter = new ArrayAdapter<String>(getContext(),
                android.R.layout.simple_list_item_1, nickNames);
        vehicleNicknameAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        nicknameSpinner.setAdapter(vehicleNicknameAdapter);

        return root;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        Dialog dialog = super.onCreateDialog(savedInstanceState);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        return dialog;
    }


    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        menu.clear();
        getActivity().getMenuInflater().inflate(R.menu.menu_create_dialog, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId())
        {
            case R.id.action_save:
                new Thread(new Runnable() {
                    @Override
                    public void run() {

                        int cost = Integer.parseInt(edtCost.getText().toString());
                        String costs = NumberFormat.getCurrencyInstance(Locale.US).format(cost);

                        Activity activity = new Activity(
                                userID,
                                edtDate.getText().toString(),
                                edtNickname.getSelectedItem().toString(),
                                costs,
                                edtActivityType.getSelectedItem().toString(),
                                edtLocation.getText().toString(),
                                edtMiles.getText().toString());
                        AppDatabase.getInstance(getContext())
                                .activityDAO()
                                .insert(activity);
                    }
                }).start();
                dismiss();
                return true;

            case android.R.id.home:
                dismiss();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }

    }
}