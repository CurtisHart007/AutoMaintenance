package com.finalproject.curtis.automaintenance.db;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.Ignore;
import android.arch.persistence.room.PrimaryKey;

@Entity
public class Vehicle {

    @PrimaryKey(autoGenerate = true)
    private int vehicleid;

    @ColumnInfo(name="user_id")
    private int userid;

    @ColumnInfo(name="vehicle_nickname")
    private String vehiclenickname;

    @ColumnInfo(name="vehicle_type")
    private String vehicletype;

    @ColumnInfo(name="vehicle_year")
    private String vehicleyear;

    @ColumnInfo(name="vehicle_make")
    private String vehiclemake;

    @ColumnInfo(name="vehicle_model")
    private String vehiclemodel;


    @Ignore
    public Vehicle() {}

    @Ignore
    public Vehicle(int userid, String vehiclenickname, String vehicletype, String vehicleyear, String vehiclemake, String vehiclemodel) {
        this.userid = userid;
        this.vehiclenickname = vehiclenickname;
        this.vehicletype = vehicletype;
        this.vehicleyear = vehicleyear;
        this.vehiclemake = vehiclemake;
        this.vehiclemodel = vehiclemodel;
    }

    public Vehicle(String vehiclenickname, String vehicletype, String vehicleyear, String vehiclemake, String vehiclemodel) {
        this.vehiclenickname = vehiclenickname;
        this.vehicletype = vehicletype;
        this.vehicleyear = vehicleyear;
        this.vehiclemake = vehiclemake;
        this.vehiclemodel = vehiclemodel;
    }

    @Ignore


    public Vehicle(int vehicleid, int userid, String vehiclenickname, String vehicletype, String vehicleyear, String vehiclemake, String vehiclemodel) {
        this.vehicleid = vehicleid;
        this.userid = userid;
        this.vehiclenickname = vehiclenickname;
        this.vehicletype = vehicletype;
        this.vehicleyear = vehicleyear;
        this.vehiclemake = vehiclemake;
        this.vehiclemodel = vehiclemodel;
    }

    public int getVehicleid() {
        return vehicleid;
    }

    public void setVehicleid(int vehicleid) {
        this.vehicleid = vehicleid;
    }

    public int getUserid() {
        return userid;
    }

    public void setUserid(int userid) {
        this.userid = userid;
    }

    public String getVehiclenickname() {
        return vehiclenickname;
    }

    public void setVehiclenickname(String vehiclenickname) {
        this.vehiclenickname = vehiclenickname;
    }

    public String getVehicletype() {
        return vehicletype;
    }

    public void setVehicletype(String vehicletype) {
        this.vehicletype = vehicletype;
    }

    public String getVehicleyear() {
        return vehicleyear;
    }

    public void setVehicleyear(String vehicleyear) {
        this.vehicleyear = vehicleyear;
    }

    public String getVehiclemake() {
        return vehiclemake;
    }

    public void setVehiclemake(String vehiclemake) {
        this.vehiclemake = vehiclemake;
    }

    public String getVehiclemodel() {
        return vehiclemodel;
    }

    public void setVehiclemodel(String vehiclemodel) {
        this.vehiclemodel = vehiclemodel;
    }

    @Override
    public String toString() {
        return "Vehicle{" +
                "vehicleid=" + vehicleid +
                ", userid=" + userid +
                ", vehiclenickname='" + vehiclenickname + '\'' +
                ", vehicletype='" + vehicletype + '\'' +
                ", vehicleyear='" + vehicleyear + '\'' +
                ", vehiclemake='" + vehiclemake + '\'' +
                ", vehiclemodel='" + vehiclemodel + '\'' +
                '}';
    }
}
