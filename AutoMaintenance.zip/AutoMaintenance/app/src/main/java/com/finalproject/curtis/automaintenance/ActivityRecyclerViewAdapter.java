package com.finalproject.curtis.automaintenance;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.finalproject.curtis.automaintenance.db.Activity;
import java.util.List;

public class ActivityRecyclerViewAdapter extends RecyclerView.Adapter<ActivityRecyclerViewAdapter.ViewHolder>{

    private final List<Activity> activities;
    private Context context;

    public ActivityRecyclerViewAdapter(List<Activity> activities, Context context) {
        this.activities = activities;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.recycler_item, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        Log.d("test", "bind: "+position);
        final Activity activity = activities.get(position);
        if (activity != null)
        {
            holder.activity = activity;
            holder.tvItem1.setText(activity.getLocation());
            holder.tvItem2.setText(activity.getDate());
            holder.tvItem3.setText(activity.getVehicleNickname());
            holder.tvItem4.setText(activity.getActivityType());
            holder.tvItem5.setText(activity.getCost());

            holder.view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    int id = activity.getAid();
                    int userid = activity.getUserID();
                    String idValue = Integer.toString(id);
                    String userValue = Integer.toString(userid);

                    Intent intent = new Intent(context, ActivityFragment.class);
                    intent.putExtra("id", idValue);
                    intent.putExtra("userid", userValue);
                    intent.putExtra("nickname", activity.getVehicleNickname());
                    intent.putExtra("activityType", activity.getActivityType());
                    intent.putExtra("date", activity.getDate());
                    intent.putExtra("location", activity.getLocation());
                    intent.putExtra("miles", activity.getOdometerMiles());
                    intent.putExtra("cost", activity.getCost());
                    context.startActivity(intent);

                }
            });
        }
    }

    @Override
    public int getItemCount() {
        Log.d("test", "itemCount: "+activities.size());
        return activities.size();
    }

    public void updateData(List<Activity> activities) {
        this.activities.clear();
        this.activities.addAll(activities);
        notifyDataSetChanged();
        Log.d("test", "Update Items: "+ activities.toString());
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView tvItem1, tvItem2, tvItem3, tvItem4, tvItem5;
        public Activity activity;
        public View view;

        public ViewHolder(View itemView) {
            super(itemView);
            view = itemView;
            tvItem1 = (TextView) itemView.findViewById(R.id.item1);
            tvItem2 = (TextView) itemView.findViewById(R.id.item2);
            tvItem3 = (TextView) itemView.findViewById(R.id.item3);
            tvItem4 = (TextView) itemView.findViewById(R.id.item4);
            tvItem5 = (TextView) itemView.findViewById(R.id.item5);
        }
    }
}
