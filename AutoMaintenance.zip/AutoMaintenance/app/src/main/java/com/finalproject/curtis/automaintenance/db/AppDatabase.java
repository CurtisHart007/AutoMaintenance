package com.finalproject.curtis.automaintenance.db;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;

@Database(entities = {Activity.class, User.class, Vehicle.class}, version = 1, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {

    private static AppDatabase instance;

    public static AppDatabase getInstance(Context context) {
        if (instance != null)
            return instance;

        instance = Room.databaseBuilder(context, AppDatabase.class, "activity-database")
                .allowMainThreadQueries()
                .build();
        return instance;
    }

    public abstract ActivityDAO activityDAO();
    public abstract UserDAO userDAO();
    public abstract VehicleDAO vehicleDAO();
}
