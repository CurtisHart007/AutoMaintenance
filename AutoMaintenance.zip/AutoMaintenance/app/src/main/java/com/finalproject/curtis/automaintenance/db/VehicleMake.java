package com.finalproject.curtis.automaintenance.db;

public class VehicleMake {

    private String make_display;

    public VehicleMake(){

    }

    public VehicleMake(String make_display) {
        this.make_display = make_display;
    }

    public String getMake_display() {
        return make_display;
    }

    public void setMake_display(String make_display) {
        this.make_display = make_display;
    }


    @Override
    public String toString() {
        return make_display;
    }
}
