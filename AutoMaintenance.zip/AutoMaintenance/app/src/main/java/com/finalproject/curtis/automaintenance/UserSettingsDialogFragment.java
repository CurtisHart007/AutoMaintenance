package com.finalproject.curtis.automaintenance;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputEditText;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import com.finalproject.curtis.automaintenance.db.AppDatabase;
import com.finalproject.curtis.automaintenance.db.User;

public class UserSettingsDialogFragment extends DialogFragment  {

    private View root;
    private TextInputEditText fullName;
    private TextInputEditText userName;
    private TextInputEditText emailAddress;
    private TextInputEditText phoneNumber;
    private TextInputEditText password;


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        root = inflater.inflate(R.layout.dialog_user_settings, container, false);
        setCancelable(false);

        Toolbar toolbar = (Toolbar) root.findViewById(R.id.toolbar1);
        toolbar.setTitle("User Information");

        ((AppCompatActivity) getActivity()).setSupportActionBar(toolbar);

        ActionBar actionBar = ((AppCompatActivity) getActivity()).getSupportActionBar();

        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeButtonEnabled(true);
            actionBar.setHomeAsUpIndicator(android.R.drawable.ic_menu_close_clear_cancel);
        }

        setHasOptionsMenu(true);

        fullName = (TextInputEditText) root.findViewById(R.id.fullnameValue);
        userName = (TextInputEditText) root.findViewById(R.id.usernameValue);
        emailAddress = (TextInputEditText) root.findViewById(R.id.emailValue);
        phoneNumber = (TextInputEditText) root.findViewById(R.id.phoneValue);
        password = (TextInputEditText) root.findViewById(R.id.passwordValue);

        return root;
    }


    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        menu.clear();
        getActivity().getMenuInflater().inflate(R.menu.menu_create_dialog, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId())
        {
            case R.id.action_save:
                new Thread(new Runnable() {
                    @Override
                    public void run() {

                        String fullnameText = fullName.getText().toString();
                        String usernameText = userName.getText().toString();
                        String emailText = emailAddress.getText().toString();
                        String phoneText = phoneNumber.getText().toString();
                        String passwordText = password.getText().toString();

                        User user = new User(
                                fullnameText,
                                usernameText,
                                passwordText,
                                emailText,
                                phoneText
                                );

                        AppDatabase.getInstance(getContext())
                                .userDAO()
                                .insert(user);
                    }
                }).start();
                dismiss();
                return true;

            case android.R.id.home:
                dismiss();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

}
