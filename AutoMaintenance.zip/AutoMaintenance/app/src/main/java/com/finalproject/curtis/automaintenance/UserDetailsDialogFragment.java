package com.finalproject.curtis.automaintenance;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputEditText;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import com.finalproject.curtis.automaintenance.db.AppDatabase;
import com.finalproject.curtis.automaintenance.db.User;
import java.util.List;

public class UserDetailsDialogFragment extends DialogFragment {

    private View root;
    private Context context;
    private TextInputEditText fullName;
    private TextView userName;
    private TextInputEditText emailAddress;
    private TextInputEditText phoneNumber;
    private TextInputEditText password;
    private Button btnUpdate;
    private String username = "";


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        root = inflater.inflate(R.layout.dialog_user_details, container, false);
        setCancelable(false);

        Toolbar toolbar = (Toolbar) root.findViewById(R.id.toolbar1);
        toolbar.setTitle("User Information");

        ((AppCompatActivity) getActivity()).setSupportActionBar(toolbar);

        ActionBar actionBar = ((AppCompatActivity) getActivity()).getSupportActionBar();

        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeButtonEnabled(true);
            actionBar.setHomeAsUpIndicator(android.R.drawable.ic_menu_close_clear_cancel);
        }

        setHasOptionsMenu(true);

        fullName = (TextInputEditText) root.findViewById(R.id.fullnameValue);
        userName = (TextView) root.findViewById(R.id.usernameValue);
        emailAddress = (TextInputEditText) root.findViewById(R.id.emailValue);
        phoneNumber = (TextInputEditText) root.findViewById(R.id.phoneValue);
        password = (TextInputEditText) root.findViewById(R.id.passwordValue);
        btnUpdate = (Button) root.findViewById(R.id.btnUserUpdate);

        username = "";
        Bundle bundle = this.getArguments();
        if (bundle != null) {
            username = bundle.getString("username", "none");
        }

        List<User> users = AppDatabase.getInstance(getContext()).userDAO().getAllByUsername(username);

        for(User usr : users) {
            String fullnameText = usr.getFullname();
            String usernameText = usr.getUsername();
            String passwordText = usr.getPassword();
            String emailText = usr.getEmail();
            String phoneText = usr.getPhone();

            fullName.setText(fullnameText);
            userName.setText(usernameText);
            //password.setText(passwordText);
            emailAddress.setText(emailText);
            phoneNumber.setText(phoneText);

        }

        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                new Thread(new Runnable() {
                    @Override
                    public void run() {

                        int userID = 0;
                        List<User> users1 = AppDatabase.getInstance(getContext()).userDAO().getAllByUsername(username);

                        for(User usr : users1) {
                            userID = usr.getUserID();
                        }

                        String fullnameText = fullName.getText().toString();
                        String usernameText = userName.getText().toString();
                        String passwordText = password.getText().toString();
                        String passwordValue = "";

                        if (passwordText.equals("")) {
                            List<User> users = AppDatabase.getInstance(getContext()).userDAO().getAllByUsername(username);

                            for(User usr : users) {
                                passwordValue = usr.getPassword();
                            }
                        } else {
                            passwordValue = passwordText;
                        }

                        String emailText = emailAddress.getText().toString();
                        String phoneText = phoneNumber.getText().toString();

                        User user = new User(
                                userID,
                                fullnameText,
                                usernameText,
                                passwordValue,
                                emailText,
                                phoneText);

                        AppDatabase.getInstance(getContext()).userDAO().update(user);
                    }
                }).start();
                dismiss();
            }
        });

        return root;
    }



    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {

        menu.clear();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId())
        {
            case android.R.id.home:
                dismiss();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }



    public String getUsername() {
        String username;

        if(getActivity().getIntent().hasExtra("username")) {
            username = getActivity().getIntent().getStringExtra("username");
        } else {
            username = "";
        }
        return username;
    }
}
