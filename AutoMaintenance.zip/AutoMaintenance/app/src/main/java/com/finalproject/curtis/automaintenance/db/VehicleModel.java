package com.finalproject.curtis.automaintenance.db;

public class VehicleModel {

    private String model_name;

    public VehicleModel() {
    }

    public VehicleModel(String model_name) {
        this.model_name = model_name;
    }

    public String getModel_name() {
        return model_name;
    }

    public void setModel_name(String model_name) {
        this.model_name = model_name;
    }

    @Override
    public String toString() {
        return model_name;
    }
}
