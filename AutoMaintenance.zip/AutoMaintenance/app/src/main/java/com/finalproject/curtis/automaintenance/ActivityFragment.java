package com.finalproject.curtis.automaintenance;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import com.finalproject.curtis.automaintenance.db.Activity;
import com.finalproject.curtis.automaintenance.db.AppDatabase;
import com.finalproject.curtis.automaintenance.db.User;
import com.finalproject.curtis.automaintenance.db.Vehicle;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ActivityFragment extends AppCompatActivity {

    private Context context;
    private int idValue;
    private int useridValue;
    private Spinner nickname;
    private Spinner activityType;
    private TextView date;
    private TextInputEditText location;
    private TextInputEditText miles;
    private TextInputEditText cost;
    private Button update;
    private Button delete;
    private Button cancel;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_activity);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar1);
        toolbar.setTitle("Activity Details");

        nickname = (Spinner) findViewById(R.id.NicknameValue);
        activityType = (Spinner) findViewById(R.id.ActivityTypeSpinner);
        date = (TextView) findViewById(R.id.DateValue);
        location = (TextInputEditText) findViewById(R.id.LocationValue);
        miles = (TextInputEditText) findViewById(R.id.MilesValue);
        cost = (TextInputEditText) findViewById(R.id.CostValue);

        update = (Button) findViewById(R.id.btnUpdate);
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){

                new Thread(new Runnable() {
                    @Override
                    public void run() {

                        String nicknameText = nickname.getSelectedItem().toString();
                        String dateText = date.getText().toString();
                        String activityTypeText = activityType.getSelectedItem().toString();
                        String locationText = location.getText().toString();
                        String milesText = miles.getText().toString();
                        String costText = cost.getText().toString();
                        int cost;
                        String costs;

                        if (costText.contains("$")) {
                            costs = costText;
                        } else {
                            cost = Integer.parseInt(costText);
                            costs = NumberFormat.getCurrencyInstance(Locale.US).format(cost);
                        }

                        Activity activity = new Activity(
                                            idValue,
                                            useridValue,
                                            dateText,
                                            nicknameText,
                                            costs,
                                            activityTypeText,
                                            locationText,
                                            milesText);

                        context = ActivityFragment.this;
                        AppDatabase.getInstance(context)
                                .activityDAO()
                                .update(activity);
                    }
                }).start();

                String userIDnew = Integer.toString(useridValue);
                context = ActivityFragment.this;
                Intent intent = new Intent(context, RecyclerFragment.class);
                intent.putExtra("id", userIDnew);
                context.startActivity(intent);
            }

        });

        delete = (Button) findViewById(R.id.btnDelete);
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                new Thread(new Runnable() {
                    @Override
                    public void run() {

                        String nicknameText = nickname.getSelectedItem().toString();
                        String dateText = date.getText().toString();
                        String activityTypeText = activityType.getSelectedItem().toString();
                        String locationText = location.getText().toString();
                        String milesText = miles.getText().toString();
                        String costText = cost.getText().toString();
                        int cost;
                        String costs;

                        if (costText.contains("$")) {
                            costs = costText;
                        } else {
                            cost = Integer.parseInt(costText);
                            costs = NumberFormat.getCurrencyInstance(Locale.US).format(cost);
                        }

                        Activity activity = new Activity(
                                idValue,
                                useridValue,
                                dateText,
                                nicknameText,
                                costs,
                                activityTypeText,
                                locationText,
                                milesText);

                        context = ActivityFragment.this;
                        AppDatabase.getInstance(context)
                                .activityDAO()
                                .delete(activity);
                    }
                }).start();

                String userIDnew = Integer.toString(useridValue);
                context = ActivityFragment.this;
                Intent intent = new Intent(context, RecyclerFragment.class);
                intent.putExtra("id", userIDnew);
                context.startActivity(intent);

            }
        });

        cancel = (Button) findViewById(R.id.btnCancel);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){

                String userIDnew = Integer.toString(useridValue);
                context = ActivityFragment.this;
                Intent intent = new Intent(context, RecyclerFragment.class);
                intent.putExtra("id", userIDnew);
                startActivity(intent);
            }

        });

        getIncomingIntent();
    }


    private void getIncomingIntent() {
        if(     getIntent().hasExtra("id") &&
                getIntent().hasExtra("userid") &&
                getIntent().hasExtra("nickname") &&
                getIntent().hasExtra("activityType") &&
                getIntent().hasExtra("date") &&
                getIntent().hasExtra("location") &&
                getIntent().hasExtra("miles") &&
                getIntent().hasExtra("cost")) {

            String id = getIntent().getStringExtra("id");
            String userid = getIntent().getStringExtra("userid");

            idValue = Integer.parseInt(id);
            useridValue = Integer.parseInt(userid);

            String nick = getIntent().getStringExtra("nickname");
            String type = getIntent().getStringExtra("activityType");
            String dates = getIntent().getStringExtra("date");
            String locations = getIntent().getStringExtra("location");
            String odometermiles = getIntent().getStringExtra("miles");
            String costs = getIntent().getStringExtra("cost");

            setTextValues(nick, type, dates, locations, odometermiles, costs);
        }
    }

    private void setTextValues(String nicknameValue, String typeValue, String dateValue, String locationValue, String milesValue, String costsValue) {

        // Set up String ArrayList for all vehicleNicknames
        ArrayList<String> nickNames = new ArrayList<String>();

        List<Vehicle> vehicles = AppDatabase.getInstance(this).vehicleDAO().loadByUserID(useridValue);
        String vehicleName = "";

        for(Vehicle vehc : vehicles) {
            vehicleName = vehc.getVehiclenickname();

            nickNames.add(vehicleName);
        }

        Spinner nicknameSpinner = (Spinner) findViewById(R.id.NicknameValue);

        ArrayAdapter<String> vehicleNicknameAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, nickNames);
        vehicleNicknameAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        nicknameSpinner.setAdapter(vehicleNicknameAdapter);
        nicknameSpinner.setSelection(vehicleNicknameAdapter.getPosition(nicknameValue));

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.activityNames, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        activityType.setAdapter(adapter);
        if (typeValue != null) {
            int spinnerPosition = adapter.getPosition(typeValue);
            activityType.setSelection(spinnerPosition);
        }

        date.setText(dateValue);
        location.setText(locationValue);
        miles.setText(milesValue);
        cost.setText(costsValue);
    }


    // ---------------------- Dismiss Keyboard when Click Away -------------------------
    // ---------------------------------------------------------------------------------
    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (getCurrentFocus() != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        }
        return super.dispatchTouchEvent(ev);
    }
}