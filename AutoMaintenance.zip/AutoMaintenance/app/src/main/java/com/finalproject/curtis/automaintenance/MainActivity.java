package com.finalproject.curtis.automaintenance;

import android.app.FragmentTransaction;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.TextInputEditText;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.Toast;
import com.finalproject.curtis.automaintenance.db.AppDatabase;
import com.finalproject.curtis.automaintenance.db.User;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private Context context;
    private Button login;
    private TextInputEditText loginValue;
    private Button createUser;
    private TextInputEditText passwordValue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_login);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        loginValue = (TextInputEditText) findViewById(R.id.username);
        passwordValue = (TextInputEditText) findViewById(R.id.password);


        login = (Button) findViewById(R.id.btnLogin);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String usernameText = loginValue.getText().toString();
                String passwordText = passwordValue.getText().toString();
                String password = "";

                List<User> users = AppDatabase.getInstance(MainActivity.this).userDAO().getAllByUsername(usernameText);

                for(User usr : users) {
                    password = usr.getPassword();
                }

                if (passwordText.equals(password)) {
                    context = MainActivity.this;
                    Intent intent = new Intent(context, RecyclerFragment.class);
                    intent.putExtra("username", loginValue.getText().toString());
                    context.startActivity(intent);
                } else {
                    Context context = getApplicationContext();
                    String text = "Username & Password do not match. Please try again.";
                    int duration = Toast.LENGTH_SHORT;

                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                }
            }
        });

        createUser = (Button) findViewById(R.id.btnCreateUser);
        createUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager fm1 = getSupportFragmentManager();
                UserSettingsDialogFragment dialog1 = new UserSettingsDialogFragment();
                fm1.beginTransaction()
                        .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
                        .add(android.R.id.content, dialog1)
                        .addToBackStack(null)
                        .commit();
            }
        });
    }



    // ---------------------- Dismiss Keyboard when Click Away -------------------------
    // ---------------------------------------------------------------------------------

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (getCurrentFocus() != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        }
        return super.dispatchTouchEvent(ev);
    }
}
