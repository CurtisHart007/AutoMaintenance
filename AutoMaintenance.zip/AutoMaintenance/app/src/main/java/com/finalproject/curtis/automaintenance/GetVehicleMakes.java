package com.finalproject.curtis.automaintenance;

import android.os.AsyncTask;
import android.util.Log;
import com.finalproject.curtis.automaintenance.db.VehicleMake;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import javax.net.ssl.HttpsURLConnection;

import retrofit2.http.GET;

public class GetVehicleMakes extends AsyncTask<String, Integer, String> {

    private String rawJSON;
    private OnVehicleMakeListComplete mCallback;
    private String year;

    public interface OnVehicleMakeListComplete {
       void processVehicleMakeList(VehicleMake[] vehicleMakes);
    }

    public void setOnVehicleMakeListComplete(OnVehicleMakeListComplete listener) {
        mCallback = listener;
    }


    @Override
    protected String doInBackground(String... strings) {

        year = strings[0];

        try {
            URL url = new URL("https://www.carqueryapi.com/api/0.3/?callback=?&cmd=getMakes&year=" + year + "&sold_in_us=1");
            HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();

            connection.setRequestMethod("GET");

            connection.connect();

            int status = connection.getResponseCode();

            switch (status)
            {
                case 200:
                case 201:
                    BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    rawJSON = br.readLine();
                    rawJSON = rawJSON.substring(11,rawJSON.length()-3);
                    Log.d("test", "rawJSON Length: " + rawJSON.length());
                    Log.d("test", "rawJSON: " + rawJSON);

                    break;
            }

        } catch (MalformedURLException e) {
            Log.d("test", "BAD URL. Unable to connect.");
        } catch (IOException e) {
            Log.d("test", "Unable to connect. Do you have I/O");
        }

        return rawJSON;
    }

    @Override
    protected void onPostExecute(String result) {
        super.onPostExecute(result);

        VehicleMake[] vehicleMakes;

        try {
            vehicleMakes = parseJson(result);
            if (vehicleMakes != null) {
                //SEND
                if (mCallback != null && mCallback instanceof OnVehicleMakeListComplete) {
                    mCallback.processVehicleMakeList(vehicleMakes);
                } else {
                    throw new Exception("Must implement OnVehicleMakeListComplete interface");
                }
            }
        }
        catch (Exception e) {
            Log.d("test", e.getMessage());
        }
    }

    private VehicleMake[] parseJson(String result) {

        GsonBuilder gsonb = new GsonBuilder();
        Gson gson = gsonb.create();

        VehicleMake[] vehiclemakes = null;

        try {
            vehiclemakes = gson.fromJson(rawJSON, VehicleMake[].class);
            Log.d("test", "Make Count: " + vehiclemakes.length);
        }
        catch (Exception e) {
            Log.d("test", e.getMessage());
        }

        return vehiclemakes;
    }

}
