package com.finalproject.curtis.automaintenance;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.design.widget.TextInputEditText;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import com.finalproject.curtis.automaintenance.db.AppDatabase;
import com.finalproject.curtis.automaintenance.db.User;
import com.finalproject.curtis.automaintenance.db.Vehicle;
import com.finalproject.curtis.automaintenance.db.VehicleMake;
import com.finalproject.curtis.automaintenance.db.VehicleModel;
import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import retrofit2.Call;

public class NewVehichleDialogFragment extends DialogFragment {

    private View root;
    private TextInputEditText vehicleNickname;
    private Spinner vehicleType;
    private Spinner vehicleYear;
    private Spinner vehicleMake;
    private Spinner vehicleModel;
    private String username = "";
    private GetVehicleMakes taskMakes;
    private GetVehicleModels taskModels;


    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        root = inflater.inflate(R.layout.dialog_new_vehicle, container, false);
        setCancelable(false);

        Toolbar toolbar = (Toolbar) root.findViewById(R.id.toolbar1);
        toolbar.setTitle("New Vehicle");

        ((AppCompatActivity) getActivity()).setSupportActionBar(toolbar);

        ActionBar actionBar = ((AppCompatActivity) getActivity()).getSupportActionBar();

        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeButtonEnabled(true);
            actionBar.setHomeAsUpIndicator(android.R.drawable.ic_menu_close_clear_cancel);
        }

        setHasOptionsMenu(true);

        vehicleNickname = (TextInputEditText) root.findViewById(R.id.edtNicknameValue);
        vehicleType = (Spinner) root.findViewById(R.id.edtVehicleTypeSpinner);
        vehicleYear = (Spinner) root.findViewById(R.id.edtVehicleYearSpinner);
        vehicleMake = (Spinner) root.findViewById(R.id.edtVehicleMakeSpinner);
        vehicleModel = (Spinner) root.findViewById(R.id.edtVehicleModelSpinner);

        // Getting UserID so I can pull vehicleNicknames based on that UserID
        Bundle bundle = this.getArguments();
        if (bundle != null) {
            username = bundle.getString("username", "none");
        }

        // Set up items in the VehicleType Spinner
        ArrayAdapter<String> vehicleTypeAdapter = new ArrayAdapter<String>(getContext(),
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.vehicleTypes));
        vehicleTypeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        vehicleType.setAdapter(vehicleTypeAdapter);

        // Set up String ArrayList for all years 1900 through Next Year
        ArrayList<String> years = new ArrayList<String>();
        int nextYear = Calendar.getInstance().get(Calendar.YEAR);
        for (int i = nextYear; i >= 1900; i--) {
            years.add(Integer.toString(i));
        }

        // Set up items in the VehicleType Spinner
        ArrayAdapter<String> vehicleYearAdapter = new ArrayAdapter<String>(getContext(),
                android.R.layout.simple_list_item_1, years);
        vehicleYearAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        vehicleYear.setAdapter(vehicleYearAdapter);

        vehicleYear.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                String yearNow = vehicleYear.getSelectedItem().toString();
                getVehicleMakes(yearNow);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
            }
        });


        vehicleMake.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                String yearNow = vehicleYear.getSelectedItem().toString();
                String makeNow = vehicleMake.getSelectedItem().toString();
                getVehicleModels(yearNow, makeNow);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
            }
        });


        return root;
    }


    public void getVehicleMakes(String year) {
        taskMakes = new GetVehicleMakes();
        taskMakes.setOnVehicleMakeListComplete(new GetVehicleMakes.OnVehicleMakeListComplete() {

            @Override
            public void processVehicleMakeList(VehicleMake[] vehicleMakes) {
                if (vehicleMakes != null) {

                    ArrayList<VehicleMake> vehicleMakeList = new ArrayList<>();
                    for (VehicleMake make:vehicleMakes){
                        vehicleMakeList.add(make);
                    }

                    // Set up items in the VehicleMake Spinner
                    ArrayAdapter<VehicleMake> vehicleMakeAdapter = new ArrayAdapter<VehicleMake>(getContext(),
                            android.R.layout.simple_list_item_1, vehicleMakeList);
                    vehicleMakeAdapter.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item);
                    vehicleMake.setAdapter(vehicleMakeAdapter);
                }
            }
        });
        taskMakes.execute(year);

    }

    public void getVehicleModels(String year, String make) {
        taskModels = new GetVehicleModels();
        taskModels.setOnVehicleModelListComplete(new GetVehicleModels.OnVehicleModelListComplete() {

            @Override
            public void processVehicleModelList(VehicleModel[] vehicleModels) {
                if (vehicleModels != null) {

                    ArrayList<VehicleModel> vehicleModelList = new ArrayList<>();
                    for (VehicleModel model:vehicleModels){
                        vehicleModelList.add(model);
                    }

                    // Set up items in the VehicleMake Spinner
                    ArrayAdapter<VehicleModel> vehicleModelAdapter = new ArrayAdapter<VehicleModel>(getContext(),
                            android.R.layout.simple_list_item_1, vehicleModelList);
                    vehicleModelAdapter.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item);
                    vehicleModel.setAdapter(vehicleModelAdapter);
                }
            }
        });
        taskModels.execute(year, make);

    }


    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        menu.clear();
        getActivity().getMenuInflater().inflate(R.menu.menu_create_dialog, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId())
        {
            case R.id.action_save:
                new Thread(new Runnable() {
                    @Override
                    public void run() {

                        int userID = 0;
                        List<User> users1 = AppDatabase.getInstance(getContext()).userDAO().getAllByUsername(username);

                        for(User usr : users1) {
                            userID = usr.getUserID();
                        }

                        Vehicle vehicle = new Vehicle(
                                userID,
                                vehicleNickname.getText().toString(),
                                vehicleType.getSelectedItem().toString(),
                                vehicleYear.getSelectedItem().toString(),
                                vehicleMake.getSelectedItem().toString(),
                                vehicleModel.getSelectedItem().toString());
                        AppDatabase.getInstance(getContext())
                                .vehicleDAO()
                                .insert(vehicle);


                        Log.d("test", "Add Vehicle: "+ vehicle.toString());
                    }
                }).start();

                dismiss();
                return true;

            case android.R.id.home:
                dismiss();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }

    }
}
