package com.finalproject.curtis.automaintenance;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.finalproject.curtis.automaintenance.db.Activity;
import com.finalproject.curtis.automaintenance.db.AppDatabase;
import com.finalproject.curtis.automaintenance.db.User;

import java.util.ArrayList;
import java.util.List;

public class MainActivityFragment extends Fragment {

    private RecyclerView recyclerView;
    private ActivityRecyclerViewAdapter adapter;
    private int columnCount = 1;
    private View root;
    private int userID;
    private String usernameText = "";

    public MainActivityFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        root = inflater.inflate(R.layout.fragment_main, container, false);

        recyclerView = (RecyclerView) root.findViewById(R.id.rvActivityList);

        if(getActivity().getIntent().hasExtra("username")){
           usernameText = getActivity().getIntent().getStringExtra("username");
        }

        List<User> users = AppDatabase.getInstance(getContext()).userDAO().getAllByUsername(usernameText);

        for(User usr : users) {
            userID = usr.getUserID();
        }

        return root;
    }


    @Override
    public void onResume() {
        super.onResume();

        if(getActivity().getIntent().hasExtra("id")){
            String value = getActivity().getIntent().getStringExtra("id");

            if (value == null){
                userID = 1;
            } else {
                userID = Integer.parseInt(value);
            }

        }

        Context context = getContext();
        adapter = new ActivityRecyclerViewAdapter(new ArrayList<Activity>(), context);
        if (columnCount <= 1)
        {
            recyclerView.setLayoutManager(new LinearLayoutManager(context));
        }
        else
        {
            recyclerView.setLayoutManager(new GridLayoutManager(context, columnCount));
        }

        recyclerView.setAdapter(adapter);
        recyclerView.setHasFixedSize(false);

        ViewModelProviders.of(this)
                .get(AllActivitiesViewModel.class)
                .getActivityList(context, userID)
                .observe(this, new Observer<List<Activity>>() {
                    @Override
                    public void onChanged(@Nullable List<Activity> activities) {
                        if(activities != null)
                        {
                            adapter.updateData(activities);
                        }
                    }
                });
    }

}
