package com.finalproject.curtis.automaintenance.db;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;
import java.util.List;

@Dao
public interface VehicleDAO {

    @Query("select * from vehicle")
    LiveData<List<Vehicle>> getAll();

    @Query("select * from vehicle WHERE user_id = :userid")
    List<Vehicle> loadByUserID(int userid);

    @Query("select * from vehicle where vehicleid = :vehicleid")
    Vehicle loadByVehicleID(int vehicleid);

    @Update
    void update(Vehicle vehicle);

    @Delete
    void delete(Vehicle vehicle);

    @Insert
    void insert(Vehicle... vehicles);

}
