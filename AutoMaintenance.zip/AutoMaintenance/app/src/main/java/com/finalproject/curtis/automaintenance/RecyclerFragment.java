package com.finalproject.curtis.automaintenance;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

public class RecyclerFragment extends AppCompatActivity {

    private Context context;
    String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                username = getUsername();
                Bundle arguments = new Bundle();
                arguments.putString("username", username);

                FragmentManager fm = getSupportFragmentManager();
                NewActivityDialogFragment dialog = new NewActivityDialogFragment();
                dialog.setArguments(arguments);
                fm.beginTransaction()
                        .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
                        .add(android.R.id.content, dialog)
                        .addToBackStack(null)
                        .commit();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);

        getMenuInflater().inflate(R.menu.menu_main, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_user_details:
                username = getUsername();
                Bundle arguments = new Bundle();
                arguments.putString("username", username);

                FragmentManager fm1 = getSupportFragmentManager();
                UserDetailsDialogFragment dialog1 = new UserDetailsDialogFragment();
                dialog1.setArguments(arguments);
                fm1.beginTransaction()
                        .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
                        .add(android.R.id.content, dialog1)
                        .addToBackStack(null)
                        .commit();
                return true;


            case R.id.action_add_vehicle:
                username = getUsername();
                Bundle arguments1 = new Bundle();
                arguments1.putString("username", username);

                FragmentManager fm2 = getSupportFragmentManager();
                NewVehichleDialogFragment dialog2 = new NewVehichleDialogFragment();
                dialog2.setArguments(arguments1);
                fm2.beginTransaction()
                        .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
                        .add(android.R.id.content, dialog2)
                        .addToBackStack(null)
                        .commit();
                return true;

            case R.id.action_logout:
                context = RecyclerFragment.this;
                Intent intent = new Intent(context, MainActivity.class);
                context.startActivity(intent);
                return true;


            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public String getUsername() {

        if(getIntent().hasExtra("username")) {
            username = getIntent().getStringExtra("username");
        } else {
            username = "";
        }
        return username;
    }


    // ---------------------- Dismiss Keyboard when Click Away -------------------------
    // ---------------------------------------------------------------------------------

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (getCurrentFocus() != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        }
        return super.dispatchTouchEvent(ev);
    }

}
