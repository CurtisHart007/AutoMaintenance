package com.finalproject.curtis.automaintenance.db;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.Ignore;
import android.arch.persistence.room.PrimaryKey;


@Entity
public class Activity {

    @PrimaryKey(autoGenerate = true)
    private int aid;

    private int userID;

    private String date;

    @ColumnInfo(name="vehicle_nickname")
    private String vehicleNickname;

    private String cost;

    @ColumnInfo(name="activity_type")
    private String activityType;

    private String location;

    @ColumnInfo(name="odometer_miles")
    private String odometerMiles;

    @Ignore
    public Activity(){}

    @Ignore
    public Activity(int userID, String date, String vehicleNickname, String cost, String activityType, String location, String odometerMiles) {
        this.userID = userID;
        this.date = date;
        this.vehicleNickname = vehicleNickname;
        this.cost = cost;
        this.activityType = activityType;
        this.location = location;
        this.odometerMiles = odometerMiles;
    }


    public Activity(int aid, int userID, String date, String vehicleNickname, String cost, String activityType, String location, String odometerMiles) {
        this.aid = aid;
        this.userID = userID;
        this.date = date;
        this.vehicleNickname = vehicleNickname;
        this.cost = cost;
        this.activityType = activityType;
        this.location = location;
        this.odometerMiles = odometerMiles;
    }

    public int getAid() { return aid; }

    public void setAid(int aid) { this.aid = aid; }

    public int getUserID() { return userID; }

    public void setUserID(int userID) { this.userID = userID; }

    public String getDate() { return date; }

    public void setDate(String date) { this.date = date; }

    public String getVehicleNickname() { return vehicleNickname; }

    public void setVehicleNickname(String vehicleNickname) { this.vehicleNickname = vehicleNickname; }

    public String getCost() { return cost; }

    public void setCost(String cost) { this.cost = cost; }

    public String getActivityType() { return activityType; }

    public void setActivityType(String activityType) { this.activityType = activityType; }

    public String getLocation() { return location; }

    public void setLocation(String location) { this.location = location; }

    public String getOdometerMiles() { return odometerMiles; }

    public void setOdometerMiles(String odometerMiles) { this.odometerMiles = odometerMiles; }


    @Override
    public String toString() {
        return "Activity{" +
                "aid=" + aid +
                ", userID=" + userID +
                ", date='" + date + '\'' +
                ", vehicleNickname='" + vehicleNickname + '\'' +
                ", cost=" + cost +
                ", activityType='" + activityType + '\'' +
                ", location='" + location + '\'' +
                ", odometerMiles=" + odometerMiles +
                '}';
    }


}
