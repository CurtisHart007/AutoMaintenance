package com.finalproject.curtis.automaintenance;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.ViewModel;
import android.content.Context;
import com.finalproject.curtis.automaintenance.db.Activity;
import com.finalproject.curtis.automaintenance.db.AppDatabase;
import java.util.List;

public class AllActivitiesViewModel extends ViewModel {
    private LiveData<List<Activity>> activityList;

    public LiveData<List<Activity>> getActivityList(Context c, int userID) {
        if (activityList != null)
            return activityList;

        return activityList = AppDatabase.getInstance(c).activityDAO().getAll(userID);
    }

}
